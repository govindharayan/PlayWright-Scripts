function getWeekRange(selectedDate) {
    const startDate = new Date(selectedDate);
    const endDate = new Date(selectedDate);
   
    // Find the start of the week (Sunday)
    startDate.setDate(startDate.getDate() - startDate.getDay()+1);
  
    // Find the end of the week (Saturday)
    endDate.setDate(endDate.getDate() + (7 - endDate.getDay()));
  
    // Format the dates
    const formattedStartDate = startDate.toLocaleDateString('en-GB', {
                day: '2-digit',
                month: 'short',
                year: '2-digit'
            }).replace(/ /g, '-');
    const formattedEndDate = endDate.toLocaleDateString('en-GB', {
                day: '2-digit',
                month: 'short',
                year: '2-digit'
            }).replace(/ /g, '-');
  
            return `${formattedStartDate} to ${formattedEndDate}`;
  }
  
 module.exports ={
    getWeekRange
 }